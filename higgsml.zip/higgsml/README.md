`docker-compose up -d`
